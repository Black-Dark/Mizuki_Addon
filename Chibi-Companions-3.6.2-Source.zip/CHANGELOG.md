# Changelog

## 3.6.2

- Rebuilt the 50 archive chibis with solid bodies, articulated limbs, and more detailed textures based on their OC Hub artwork.
- Added separate archive movement and carrying animations. Limited head rotation and removed whole-body bouncing from the archive pickup and happy animations.

## 3.6.1

- Added 50 appearances based on OC Hub chibi artwork, for 56 selectable appearances.
- Removed Silas Clive, Caelum Veyr Clive, and Kaien Tsukishiro. Companions using those appearances display as Mizuki until the owner picks another appearance.
- Split Change Appearance into pages.

## 3.6.0

- Added Silas Clive, Caelum Veyr Clive, and Kaien Tsukishiro to Change Appearance.
- Added Stay here, Follow me, and Companion status to the Snowdrop Whistle menu.
- Calling a companion clears any stale defense chase after a successful recall.

## 3.5.2

- Increased companion backpacks from 9 to 36 slots for gathering and gear recovery.

## 3.5.1

- **Guide me to my bed** uses the player's Overworld bed respawn point. Set it by using a bed first.
- Companions now approach and strike the mob that hurt their owner using scripted retaliation. Compatible add-on mobs need a health component and must report themselves as the source of the hit.

## 3.5.0

- Nearby companions recover owner-attributed death drops when there is room in the backpack. Use **Take supplies** to retrieve recovered gear before automatic sorting resumes.
- Companions retaliate when a vanilla or add-on mob attacks their owner. They do not retaliate against players or other chibi companions.

## 3.4.0

- Added **Guide me home** to the companion menu. Companions lead players in short, walkable steps toward their personal respawn point or Overworld spawn.
- Guidance waits for the player and displays compass directions when terrain blocks progress. Use **Stop guiding** to resume normal companion behavior.

## 3.3.1

- Fixed Sora getting stuck at one-block ledges. He lines up his takeoff on the lower tile, and uses the regular climb animation if the game blocks his wing hop.

## 3.3.0

- Sora flaps over nearby ledges, low obstacles, and short gaps and lands on solid ground. His scheduled jobs use the wing hop for one-block climbs.
- Added checks for blocked flight paths and unsafe landings. The other five appearances retain their ground movement.
- In-game Bedrock playtesting is pending.

## 3.2.0

- Added a per-companion appearance picker with Mizuki, Sora, Yukishiro, Shion, Lucien, and Naoki.
- Polished character models and added distinct dialogue and idle gestures. Pickaxes appear during mining and axes during chopping.
- Preserved ownership, inventory, and the original companion abilities when changing appearance.
- Package and simulated multiplayer checks passed. In-game Bedrock playtesting is pending.

## 2.3.0

- Baseline recovered from the supplied Chibi_Companions_Mizuki-3.0.mcaddon.
- Checks available here cover inventory and terrain. Record Samsung and Switch playtest results before releasing another version.
